#include <iostream>
#include <iomanip>
#include <conio.h>
#include <windows.h>
#include <string>
#include "../cvm 21.h"
#include <ctime>

using namespace std;

int main() {
// variables
	int x = 15;
	int	y = 8;
	int codeAffx = 25, codeAffy = 25;
	int effacex, effacey;
	int	bien = 0;
	int mal = 0;
	int bienx = 0, bieny = 0, malx = 0, maly = 0;
	int Bnb;
	bool trouve;
	char CMode= ' ';
	char Eval = ' ';
	char R;
	string code = "";
	char VCode = ' ';
	int BoucleCode;
	time_t LettreSecret = time(0);	// time_t est un alias � "long long"
	string Reponse;
	int nbessaie = 10;
	unsigned char back = {};
	

	
	
// constant
	const string TITRE = "JEU DES COULEURS";
	const string REGLAGE = "R\220GLAGES DE LA PARTIE"; 
	const string MODE = " Activer le mode en d\202bogage ?  (O/N) :"; 
	const string COULEUR = "(R)ouge, (V)ert, (B)leu, (J)aune, (M)auve, (C)yan";
	const string INDIC = "    #     Essais       Bien plac\202e(s)       Mal plac\202e(s)";
	const string EVALUER = " Evaluer ? (O/N) : ";
	const string CODE_SECRET_AFF = "Code secret : ";
	const string GAGNE = "Bravo, vous avez gagn\202 !  :)"; 
	const string PERDU = "Vous avez perdu !  :(";
	const string vide = " ";
	const string PARENTHESE = ")";
	const int MAX_ESSAI = 10;
	const int TITREX = 50;
	const int TITREY = 1;
	const int REGLAGEX = 47;
	const int REGLAGEY = 3;
	const int MODEX = 5;
	const int MODEY = 5;
	const int INDICX = 5;
	const int INDICY = 7;
	const int EVALUERX = 0;
	const int EVALUERY = 20;
	const int EVALx = 25; 
	const int C = 6;
	const int MAX_LETTRE = 3;
	const int TAILLEMDP = 4;
	const char COULEUR_CHOIX[C] = { 'R', 'V', 'B' , 'J' , 'M', 'C' };
	char Codeessai[TAILLEMDP];
	
	do {
	//change selon le temps
	srand(int(LettreSecret));

	// trouve le nombre secret  : GOOD
	for (int v = 0; v < 4; ++v) {
		R = COULEUR_CHOIX[rand() % C];
		Reponse += R;
	}

	// Affichage du menu Principal: GOOD
	gotoxy(TITREX, TITREY);
	cout << TITRE << endl;
	gotoxy(REGLAGEX, REGLAGEY);
	cout << REGLAGE << endl;
	gotoxy(MODEX, MODEY);
	cout << MODE;

		for (int i = 0; CMode != 'O' && CMode != 'N'; i++) {
			CMode = toupper(_getch());

		}
		//verifie O ou N
		if (CMode != 'O' && CMode != 'N') {
			gotoxy(MODEX, MODEY);
			clreol();
		}
	// affichage O ou N
	cout << CMode;
	clrscr();

		//affiche oui ou non le nmbre secret:GOOD
		if (CMode == 'O') {

			gotoxy(codeAffx, codeAffy);
			cout << CODE_SECRET_AFF;
			gotoxy(codeAffx + 15, codeAffy);
			for (int v = 0; v < 4; ++v) {
				cout << Reponse[v] << vide;
			}
		}
		else if (CMode == 'N') {

		}
		else {
			trouve = true;
			clreoscr();
		}
		
// deuxieme partie 

	//Deuxieme Titre
		gotoxy(TITREX, TITREY);
		cout << TITRE << endl;
		gotoxy(MODEX, MODEY);
		cout << COULEUR << endl;
		gotoxy(INDICX, INDICY);
		cout << INDIC << endl;

		// affiche de 1 a 10: GOOD
		for ( Bnb = 1; Bnb <= 10; Bnb++) {
			cout << setw(10) << Bnb << PARENTHESE << endl;
		}

		trouve = false; 
		bool Breponse[TAILLEMDP] = { false,false,false,false };
		for (int i = 1; !trouve; i++) {
			
			//input
			// enregistre : devrait etre good
			gotoxy(x , y);
			 code = "";//reset le code
			 effacex = x;
			 effacey = y;
			 do{
				 for (BoucleCode = 0; BoucleCode <= MAX_LETTRE; BoucleCode++) {
					 if (VCode != 'R' && VCode != 'V' && VCode != 'B' && VCode != 'J' && VCode != 'M' && VCode != 'C' && VCode != '\x8') {
						 gotoxy(x,y);
						 clreol();
					 }
					 VCode = toupper(_getch());

					 if (VCode == '\x8') {
						 
					 }
						 cout << VCode << vide;
					 code += VCode;
					 Codeessai[BoucleCode] = VCode;
				 }	 
			}while (VCode != 'R' && VCode != 'V' && VCode != 'B' && VCode != 'J' && VCode != 'M' && VCode != 'C' && VCode != '\x8');
			

			// Verifie si O ou Non est bien rentrer: GOOD
			do {
				gotoxy(EVALUERX, EVALUERY);
				cout << EVALUER;
				gotoxy(EVALx, EVALUERY);
					if (Eval != 'O' && Eval != 'N') {
						gotoxy(EVALx, EVALUERY);
						clreol();
					}
				Eval = toupper(_getch());
				cout << Eval;
				clreol();
			} while (Eval != 'O' && Eval != 'N');

			do {
				// evaluation o ou non 
				if (Eval == 'O') {
					bool Breponse[TAILLEMDP] = { false,false,false,false };
						for (int p = 0; p < 4; p++) {
							if (Reponse[p] == code[p]) {
									bien++;
									Breponse[p] = true;	
							}	
						}
						for (int p = 0; p < 4; p++) {
							for (int k = 0; k < 4; k++) {
								if (code[p] == Reponse[k] && Breponse[k] != true) {
									mal++;
									Breponse[p] = true;
									break;
								}
							}
								
						}
				}
				else if (Eval == 'N') {
					gotoxy(x, y);
					clreol();
				}

			} while (trouve == true || nbessaie == 0 );

			gotoxy(bienx + 35, bieny + 8);
			cout << bien;
			gotoxy(malx + 55, maly + 8);
			cout << mal;
			bien = 0;
			mal = 0;
			if (Reponse != code) {
				bieny++;
				nbessaie--;
				y++;
				maly++;
			}
			else if (Reponse == code) {
				gotoxy(EVALUERX, EVALUERY);
				cout << GAGNE;
				break;
			}
			if (nbessaie == 0) {
				gotoxy(EVALUERX, EVALUERY);
				cout << PERDU;
				break;
			}	
		}

	} while (trouve == true );
}
	

