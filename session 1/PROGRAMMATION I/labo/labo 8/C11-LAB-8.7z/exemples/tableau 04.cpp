#include <iostream>
#include <conio.h>

using namespace std;


// LABORATOIRE 5: REVISIT� AVEC LES TABLEAUX

int main()
{
	// EXEMPLE : LAB 5 avant les tableaux -- RAPPEL

	// data
	int freq1, freq2, freq3, freq4, freq5, freq6;	// 6 variables

	// ...

	// init
	freq1 = freq2 = freq3 = freq4 = freq5 = freq6 = 0;

	// lancers
	for (int l = 1; l <= 100; ++l)
	{
		switch (rand() % 6 + 1)
		{
			case 1: ++freq1; break;
			case 2: ++freq2; break;
			case 3: ++freq3; break;
			case 4: ++freq4; break;
			case 5: ++freq5; break;
			case 6: ++freq6; break;
		}
	}

	// ...


	// EXEMPLE -- LAB 5 avec les tableaux

	const int FACES = 6;							// d� � 6 faces
	int freq[FACES];								// 6 variables

	// init
	for (int i = 0; i < FACES; ++i)
		freq[i] = 0;

	// lancers
	for (int l = 1; l <= 100; ++l)
		freq [ rand() % FACES ] ++;



	_getch();
}