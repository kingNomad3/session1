#include <iostream>
#include <conio.h>

using namespace std;

int main()
{
	cout << "Bonjour";
	cout << endl;
	cout << endl;
	cout << " ceci est mon premier programme !!!";
	cout << endl;
	cout << endl;
	cout << "Salut";
	_getch();
}