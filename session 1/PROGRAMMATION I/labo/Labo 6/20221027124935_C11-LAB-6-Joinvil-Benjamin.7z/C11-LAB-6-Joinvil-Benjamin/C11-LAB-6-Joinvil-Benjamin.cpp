#include <iostream>  // pour le cout et le cin
#include <conio.h>   // pour le _getch()
#include <iomanip>	 // pour les manipulateurs : fixed , setprecision()
#include <string> // pour le type 
#include <iomanip>
#include "../cvm 21.h"


using namespace std;

int main() {

	//Constant
	const long MIN_LANCER = 1;
	const long MAX_LANCER = 1000000;
	const int MIN_FACE = 1;
	const int MAX_FACE = 6;

	//Variable
	long long ExAleatoire= 0;
	int face = 0;
	int NbExperience= 0;
	float nblancer = 0;
	float comtpteuraleatoire = 0;
	long double compteur1 = 0;
	long double compteur2 = 0;
	long double compteur3 = 0;
	long double compteur4 = 0;
	long double compteur5 = 0;
	long double compteur6 = 0;
	long long Compteurtotal = 0;
	double pourcentage1 = 0;
	double pourcentage2 = 0;
	double pourcentage3 = 0;
	double pourcentage4 = 0;
	double pourcentage5 = 0;
	double pourcentage6 = 0;
	double pourcentageTotale = 0; 
	

	//�tape 1:Premier for qui compte le nombre l'experience 
	for (ExAleatoire= 1; ExAleatoire<= MAX_LANCER; ExAleatoire= ExAleatoire* 10) {
		cout << "Exp�rience al\x82 atoire avec\t" << ExAleatoire<< "  lancers " << "\n\n\n" << endl; //accent
		
			//�tape 2: change selon le nombre d'exp�riences
			//�tape 2.1: ExAleatoireplus petit que 7 
			if (ExAleatoire< MAX_LANCER) {
				for (nblancer = 1; nblancer < ExAleatoire; nblancer = nblancer * 10 + 1) {
				}
				compteur1 = 0;
				compteur2 = 0;
				compteur3 = 0;
				compteur4 = 0;
				compteur5 = 0;
				compteur6 = 0;

			//�tape 3: compteur al�atoire de d�e
				long length = ExAleatoire;
				for (comtpteuraleatoire = 0; comtpteuraleatoire < ExAleatoire; ++comtpteuraleatoire) {
					 
					face = rand() % (MAX_FACE - MIN_FACE + 1) + MIN_FACE;
					
					if (face == 1) { ++compteur1; }
					else if (face == 2) { ++compteur2; }
					else if (face == 3) { ++compteur3; }
					else if (face == 4) { ++compteur4; }
					else if (face == 5) { ++compteur5; }
					else if (face == 6) { ++compteur6; }
				
				}
				
			//�tape 4 affichage des r�sultats
				//�tape 4.1 somme des comtpeur
				Compteurtotal = compteur1 + compteur2 + compteur3 + compteur4 + compteur5 + compteur6;

				//calcule des pourcentage
				pourcentage1 = (compteur1 * 100) / Compteurtotal;
				pourcentage2 = (compteur2 * 100) / Compteurtotal;
				pourcentage3 = (compteur3 * 100) / Compteurtotal;
				pourcentage4 = (compteur4 * 100) / Compteurtotal;
				pourcentage5 = (compteur5 * 100) / Compteurtotal;
				pourcentage6 = (compteur6 * 100) / Compteurtotal;

				pourcentageTotale = pourcentage1 + pourcentage2 + pourcentage3 + pourcentage4 + pourcentage5 + pourcentage6; 

				
			//�tape4.2 Affichage des donn�e
				cout << fixed;
				cout << "Face"         << setw(15) <<"fr\x82quence"<< setw(15)                                             << "Distribution\n"               << endl;
				cout << setw(3) << "1" << setw(15) << fixed << setprecision(0) << compteur1 << setw(15) << setprecision(2) << pourcentage1 << setw(2) << "%" << endl;
				cout << setw(3) << "2" << setw(15) << fixed << setprecision(0) << compteur2 << setw(15) << setprecision(2) << pourcentage2 << setw(2) << "%" << endl;
				cout << setw(3) << "3" << setw(15) << fixed << setprecision(0) << compteur3 << setw(15) << setprecision(2) << pourcentage3 << setw(2) << "%" << endl;
				cout << setw(3) << "4" << setw(15) << fixed << setprecision(0) << compteur4 << setw(15) << setprecision(2) << pourcentage4 << setw(2) << "%" << endl;
				cout << setw(3) << "5" << setw(15) << fixed << setprecision(0) << compteur5 << setw(15) << setprecision(2) << pourcentage5 << setw(2) << "%" << endl;
				cout << setw(3) << "6" << setw(15) << fixed << setprecision(0) << compteur6 << setw(15) << setprecision(2) << pourcentage6 << setw(2) << "%" << endl;
				cout << setw(19)                   << "-------\t"                           << setw(11) << setprecision(2) << "--------"                     << endl;
				cout << setw(18)                   << fixed << Compteurtotal<< setw(15)                 << pourcentageTotale               << setw(2) << "%" << endl;
				
			//�tape 4.3:Compteur de statistique cumulative
				for (int NbExperience= 1; NbExperience<= 7; NbExperience++) {
				}
				cout << "\n\nStatistique cumulative apr\x8as" << setw(2) << ++NbExperience<< setw(11)<< "experience" << endl;
					
			//�tape 5 affichage du nombre de lancers
				cout << "\n" << setw(3) << "==>" << setw(7) << fixed << setprecision(0) << nblancer << setw(8) << "lancers" << endl;
			
				cout << "\n\n\n\n\nAppuyez sur une touche pour effectuer l'exp\x82rience suivante ..."; _getch();

				clrscr();

			//�tape 2.2: ExAleatoireplus �gale � 7 
			}else if (ExAleatoire= MAX_LANCER) {


				face = rand() % (MAX_FACE - MIN_FACE + 1) + MIN_FACE;
				
				if (face == 1) { ++compteur1; }
				else if (face == 2) { ++compteur2; }
				else if (face == 3) { ++compteur3; }
				else if (face == 4) { ++compteur4; }
				else if (face == 5) { ++compteur5; }
				else if (face == 6) { ++compteur6; }
				
				
				cout << fixed;
				cout << "Face" << setw(15) << "frequence" << setw(15) << "Distribution\n" << endl;
				cout << setw(3) << "1" << setw(15) << fixed << setprecision(0) << compteur1 << setw(15) << setprecision(2) << pourcentage1 << setw(2) << "%" << endl;
				cout << setw(3) << "2" << setw(15) << fixed << setprecision(0) << compteur2 << setw(15) << setprecision(2) << pourcentage2 << setw(2) << "%" << endl;
				cout << setw(3) << "3" << setw(15) << fixed << setprecision(0) << compteur3 << setw(15) << setprecision(2) << pourcentage3 << setw(2) << "%" << endl;
				cout << setw(3) << "4" << setw(15) << fixed << setprecision(0) << compteur4 << setw(15) << setprecision(2) << pourcentage4 << setw(2) << "%" << endl;
				cout << setw(3) << "5" << setw(15) << fixed << setprecision(0) << compteur5 << setw(15) << setprecision(2) << pourcentage5 << setw(2) << "%" << endl;
				cout << setw(3) << "6" << setw(15) << fixed << setprecision(0) << compteur6 << setw(15) << setprecision(2) << pourcentage6 << setw(2) << "%" << endl;
				cout << setw(19) << "-------\t" << setw(11) << setprecision(2) << "--------" << endl;
				cout << setw(18) << fixed << Compteurtotal << setw(15) << pourcentageTotale << setw(2) << "%" << endl;

			//�tape 4.3:Compteur de statistique cumulative
				for (int NbExperience = 1; NbExperience <= 7; NbExperience++) {
				}
				cout << "\n\nStatistique cumulative apres" << setw(2) << ++NbExperience << setw(11) << "experience" << endl;

			//�tape 5 affichage du nombre de lancers
				cout << "\n" << setw(3) << "==>" << setw(7) << fixed << setprecision(0) << nblancer << setw(8) << "lancers" << endl;
				cout << "\n\n\n\n\nA U  R E V O I R !"; _getch();	
			}
	}
}


