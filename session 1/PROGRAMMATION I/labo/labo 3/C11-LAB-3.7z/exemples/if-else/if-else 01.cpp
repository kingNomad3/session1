#include <iostream>
#include <conio.h>

using namespace std;

int main ()
{
	bool condition = true;

	if (condition)
	{
		cout << "la condition est vrai";
		
		// autres instructions ici
	}
	else
	{
		cout << "la condition est fausse";

		// autres instructions ici
	}

	_getch();
}